<?php

class SiteController extends Controller
{

	public function filters()
	{
		return array('accessControl');
	}

	/**
	 * @return array rules for the "accessControl" filter.
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index,register'),
				'users'=>array('*'),
			),
			
		);
	}
	/**
	 * Declares class-based actions.
	 */
	public function actions()
	{
		return array(
			// captcha action renders the CAPTCHA image displayed on the contact page
			'captcha'=>array(
				'class'=>'CCaptchaAction',
				'backColor'=>0xFFFFFF,
			),
			// page action renders "static" pages stored under 'protected/views/site/pages'
			// They can be accessed via: index.php?r=site/page&view=FileName
			'page'=>array(
				'class'=>'CViewAction',
			),
		);
	}

	/**
	 * This is the default 'index' action that is invoked
	 * when an action is not explicitly requested by users.
	 */
	public function actionLogin()
	{
		$model=new LoginForm;

		// if it is ajax validation request
		if(isset($_POST['ajax']) && $_POST['ajax']==='login-form')
		{
			echo CActiveForm::validate($model);
			Yii::app()->end();
		}

		// collect user input data
		if(isset($_POST['LoginForm']))
		{
			$model->attributes=$_POST['LoginForm'];
			// validate user input and redirect to the previous page if valid
			if($model->validate() && $model->login())
				$this->redirect(array('eventShow/index'));
		}
		// display the login form
		$this->render('login',array('model'=>$model));
	}


	public function actionRegister(){
        $model=new Users();
		
        if(isset($_POST['Users']))
    	{
    		$model->attributes = $_POST['Users'];
            $password = hash('whirlpool',base64_decode($model->password));
            $model->confirm_password = hash('whirlpool',base64_decode($model->confirm_password));
            $model->password = $password;
            $model->status = '1';
            $model->create_at =  date('Y-m-d H:i:s');

			if($model->save())
            {  
            	$this->render('thankuPage');
                exit;
            }	
            else{
            	$model->password = "";
                $model->confirm_password = "";
            }

        }

    	$session = Yii::app()->session;
        $prefixLen = strlen(CCaptchaAction::SESSION_VAR_PREFIX);
        foreach($session->keys as $key)
        {
            if(strncmp(CCaptchaAction::SESSION_VAR_PREFIX, $key, $prefixLen) == 0)
            $session->remove($key);
        }

		$this->render('register',array('model'=>$model));
	}

	/**
	 * This is the action to handle external exceptions.
	 */
	public function actionError()
	{
		if($error=Yii::app()->errorHandler->error)
		{
			if(Yii::app()->request->isAjaxRequest)
				echo $error['message'];
			else
				$this->render('error', $error);
		}

	}

	/**
	 * Displays the contact page
	 */
	public function actionContact() {
        $model = new CONTACT; 
        if (isset($_POST['CONTACT'])) { 
			$model->attributes=$_POST['CONTACT'];
			$model->CREATED = new CDbExpression('NOW()');
			if ($model->validate()) {
				if($model->save()){
					$admin_body = $this->adminTemplate($_POST['CONTACT']);
					$user_body = $this->userTemplate($_POST['CONTACT']);
					$to_user = $_POST['CONTACT']['EMAIL_ID'];
					$to_admin = "chandu.dhaundiyal@gmail.com";
					$subject = "Contact Form Details";
					$headers = "From: eventmanagement@event.com";
					mail($to_user,$subject,$user_body,$headers);
					mail($to_admin,$subject,$admin_body,$headers);
					Yii::app()->user->setFlash('contact', 'Thank you for contacting us. We will respond to you as soon as possible.');
				}
			}
        }
        $this->render('contact', array('model' => $model));
    }
	
	protected function adminTemplate($user_data){
		
		$html = '';
		$html .= '<table><tr><td>Dear Admins,</td></tr>
		<tr><td>The following user has submitted content from the Contact Us Form</td></tr></table><br>';
		$html .='<table>
					<tr>
						<td>First Name :</td>
						<td>'.$user_data['FIRST_NAME'].'</td>
					</tr>
					<tr>
						<td>Last Name :</td>
						<td>'.$user_data['LAST_NAME'].'</td>
					</tr>
					<tr>
						<td>Email :</td>
						<td>'.$user_data['EMAIL_ID'].'</td>
					</tr>
					<tr>
						<td>Mobile Number :</td>
						<td>'.$user_data['MOBILE_NUMBER'].'</td>
					</tr>
					<tr>
						<td>Comments :</td>
						<td>'.$user_data['COMMENTS'].'</td>
					</tr>
				</table>';
				return $html;
		
	}

	protected function userTemplate($user_data){
		$name = $user_data['FIRST_NAME']." ".$user_data['LAST_NAME'];
		$html = '';
		$html .= '<table><tr><td>Dear '.$name.',</td></tr>
		<tr><td>Thank you for sharing your valuable feedback, below are the details you have submitted</td></tr></table></br>';
		$html .='<table>
					<tr>
						<td>First Name :</td>
						<td>'.$user_data['FIRST_NAME'].'</td>
					</tr>
					<tr>
						<td>Last Name :</td>
						<td>'.$user_data['LAST_NAME'].'</td>
					</tr>
					<tr>
						<td>Email :</td>
						<td>'.$user_data['EMAIL_ID'].'</td>
					</tr>
					<tr>
						<td>Mobile Number :</td>
						<td>'.$user_data['MOBILE_NUMBER'].'</td>
					</tr>
					<tr>
						<td>Comments :</td>
						<td>'.$user_data['COMMENTS'].'</td>
					</tr>
				</table></br></br>';
		$html .='<table><tr><td>Thanks</td></tr>
						<tr><td>Admin</td></tr></table>';
		return $html;
		
	}

	/**
	 * Displays the login page
	 */
	public function actionindex()
	{
		$this->redirect(array('eventShow/index'));
	}

	/**
	 * Logs out the current user and redirect to homepage.
	 */
	public function actionLogout()
	{
		Yii::app()->user->logout();
		$this->redirect(Yii::app()->homeUrl);
	}
	
	
}