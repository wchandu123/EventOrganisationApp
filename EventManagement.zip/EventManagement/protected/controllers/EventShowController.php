<?php

class EventShowController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	

	public function actionIndex()
	{
		//to get upcoming events
        $getEvents = Event::getEvents();
        //to get featured events
        $getFeaturedEvents = Event::getFeaturedEvents();

        //for searching in  event
        $model=new Event('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Event']))
			$model->attributes=$_GET['Event'];
                    
        $this->render('index',array('events'=>$getEvents,'featuredEvents'=>$getFeaturedEvents,'model'=>$model));
	}
        
    public function actionDetail($id){
        $this->render('detail',array(
            'model'=>$this->loadModel($id),
        ));
    }
        
    public function loadModel($id)
	{
		$model=EVENT::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}
                
    public function actionShareOnFb(){
    	
    }

    public function actionBooking(){
		$user_id = Yii::app()->session['id'];
        if(isset($_POST['event_id'])){
            $event_id = isset($_POST['event_id'])?$_POST['event_id']:"";
            $data = BOOKINGMODEL::model()->find(array('condition' => 'USER_ID = :USER_ID and EVENT_ID = :EVENT_ID', 'params' => array(':USER_ID'=>$user_id, ':EVENT_ID'=>$event_id)));
		    $event_model = Event::model()->find(array('condition' => 'eventID = :EVENT_ID', 'params' => array(':EVENT_ID'=>$event_id)));
			if($event_model->booked_seats >= $event_model->total_seats){
				print_r('Seats are full'); exit;
			}
            if(empty($data)){
			   $booking_model = new BOOKINGMODEL;
			   $booking_model->EVENT_ID = $event_id;
			   $booking_model->USER_ID = $user_id;
			   $booking_model->CREATED = new CDbExpression('NOW()');
				if($booking_model->save()){
				    $event_model->booked_seats = ($event_model->booked_seats + 1);
					$event_model->modified = new CDbExpression('NOW()');
					$event_model->save();
                    print_r('success'); exit;
				} else {
					
					 print_r('fail'); exit;
				}
            } else {
               print_r('exist'); exit;
            }
          
        }
		
        $this->render('booking');
    }
}
