<?php
/* @var $this MenusController */
/* @var $model Menus */
if(isset($_GET['pid'])){
	$_GET['pid'] = $_GET['pid'];
	?>
	<h4><a href="<?php echo Yii::app()->createUrl("/menus/admin") ?>">Go to parent menu</a><h4>

<?php 
}else{
	$_GET['pid'] = 0;	
}

$this->breadcrumbs=array(
	'Menuses'=>array('admin'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Create Menus', 'url'=>array('create')),
);
?>

<h1>Manage Menuses</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'menus-grid',
	'dataProvider'=>$model->search($_GET['pid']),
	'filter'=>$model,
	'columns'=>array(
		'menu_name',
		'menu_description',
		array(
			'header'=>'Parent name',
			'name'=>'parentID',
			'value'=>'($data->parentID !="0") ? Menus::model()->getModel("MENU-ID-NAME",array("menuID"=>$data->parentID)) : ""',
		),
		//'sortOrder',
		array(
		'name'=>'active',
		'value'=>'($data->active =="0") ? "Disable" : "Enable"',
		'filter'=>false
		),
		/*'sortOrder',
		'system_url',
		'active',
		'created',
		'modified',
		*/
		array(
			'class'=>'CButtonColumn',
			'template'=>'{update}{delete}{manage_menuitem}',
			'buttons'=>array
		    (
		        'manage_menuitem' => array
		        (
		            'url'=>'Yii::app()->createUrl("/menus/admin", array("pid"=>$data->menuID))',
		        	 'options'=>array(
			                'id'=>'$data->main_menuID',
			            ),
			        'label' =>'Manage Submenus'    
		        ),
		       
    		),
		),
	),
)); ?>

