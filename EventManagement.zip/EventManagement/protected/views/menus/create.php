<?php
/* @var $this MenusController */
/* @var $model Menus */

$this->breadcrumbs=array(
	'Menuses'=>array('admin'),
	'Create',
);

$this->menu=array(
	array('label'=>'Manage Menus', 'url'=>array('admin')),
);
?>

<?php

$_GET['pid'] = 0; 


?>

<h1>Create Menus</h1>

<?php $this->renderPartial('_form', array('model'=>$model,'parentID'=>$_GET['pid'])); ?>