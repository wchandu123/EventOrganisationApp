<?php
/* @var $this MenusController */
/* @var $model Menus */
/* @var $form CActiveForm */
?>

<div class="form">
<?php   if (!empty($main_menuID))
		$model->main_menuID = $main_menuID;
		
		if (!empty($parentID))
		$model->parentID = $parentID;
?>

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'menus-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
	'htmlOptions'=>array(
        'class'=>'well',
    ),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>


	<div class="row">
		<?php echo $form->labelEx($model,'parentID'); ?>
		<?php echo $form->dropDownList($model,'parentID',CHtml::listData(Menus::getList("PARENT-LIST",array('parentID'=>$model->parentID)), "menuID", "menu_name"),array('empty'=>'Select Parent')); ?>
		<?php echo $form->error($model,'parentID'); ?>
	</div>
	<div class="row">
		<?php echo $form->labelEx($model,'menu_name'); ?>
		<?php echo $form->textField($model,'menu_name',array('maxlength'=>300)); ?>
		<?php echo $form->error($model,'menu_name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'menu_description'); ?>
		<?php echo $form->textArea($model,'menu_description'); ?>
		<?php echo $form->error($model,'menu_description'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'system_url'); ?>
		<?php echo $form->textField($model,'system_url',array('maxlength'=>400)); ?>
		<?php echo $form->error($model,'system_url'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'active'); ?>
		<?php echo $form->radioButtonList($model,'active',array('1'=>'Enable','0'=>'Disable'),array(
    			'labelOptions'=>array('style'=>'display:inline'),'separator'=>'')); ?>
		<?php echo $form->error($model,'active'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->