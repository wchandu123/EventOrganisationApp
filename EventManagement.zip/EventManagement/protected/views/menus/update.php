<?php
/* @var $this MenusController */
/* @var $model Menus */

$this->breadcrumbs=array(
	'Menuses'=>array('admin'),
	$model->menuID=>array('view','id'=>$model->menuID),
	'Update',
);

$this->menu=array(
	array('label'=>'Create Menus', 'url'=>array('create')),
	array('label'=>'Manage Menus', 'url'=>array('admin')),
);
?>

<h1>Update Menus <?php echo $model->menuID; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>