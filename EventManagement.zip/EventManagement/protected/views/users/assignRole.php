<?php
/* @var $this RoleController */
/* @var $model Role */

$this->breadcrumbs=array(
	'Assign Roles'=>array('index'),
);

$this->menu=array(
	array('label'=>'Manage Role', 'url'=>array('index')),
);
?>

<h1>Assign Role</h1>

<?php $this->renderPartial('_form', array('model'=>$model,'rolemodel'=>$rolemodel)); ?>