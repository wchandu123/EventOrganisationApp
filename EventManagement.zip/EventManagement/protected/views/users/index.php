<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Users'=>array('index'),
	'Manage',
);

?>

<h1>Manage Users</h1>
<div id="changePasswordMsg"></div>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'users-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		array('header'=>'SN.',
             'value'=>'++$row',
        ),
        array(
			'header'=>'User Id',
			'name'=>'id',
			'value'=>'$data->id',
		),
		'first_name',
		'last_name',
		'email',
array(
			'class'=>'CButtonColumn',
			'template' =>'{change_password}{delete}{assign_role}',
			'buttons'=>array
		    (
		         'change_password' => array(
		         'url'=>'Yii::app()->createUrl("users/changePassword",array("id"=>$data->id))',                            
                        'options'=>array(  
                        'ajax'=>array(
                                'type'=>'POST',
                                    // ajax post will use 'url' specified above 
                                'url'=>"js:$(this).attr('href')", 
                                'update'=>'#changePasswordMsg',
                               ),
                         ),

		        	),
		         	'assign_role' =>array(
		         		'url'=>'Yii::app()->createUrl("/users/assignRole", array("id"=>$data->id))',
			        	 'options'=>array(
				                'id'=>'$data->id',
				            ),
				        'label' =>'Assign Role'  
	         		),

		       
    		),
		),
	),
)); ?>

