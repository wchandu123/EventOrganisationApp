<?php

$this->breadcrumbs = array(
	'Manage Contact' => array('admin'),
	'Manage',
);



Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$.fn.yiiGridView.update('contact-grid', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1> Manage Contact</h1>



<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id' => 'contact-grid',
	'dataProvider' => $model->search(),
	'filter' => $model,
	'columns' => array(
		//'id',
		'FIRST_NAME',
		'LAST_NAME',
		'EMAIL_ID',
		'MOBILE_NUMBER',
		'COMMENTS',
		/*
		'CAPTCHA',
		*/
		array(
			'class' => 'CButtonColumn',
			'template'=>'{view}{delete}',
		),
	),
)); ?>