<div class="form">


<?php $form = $this->beginWidget('GxActiveForm', array(
	'id' => 'contact-form',
	'enableAjaxValidation' => false,
));
?>

	<p class="note">
		<?php echo Yii::t('app', 'Fields with'); ?> <span class="required">*</span> <?php echo Yii::t('app', 'are required'); ?>.
	</p>

	<?php echo $form->errorSummary($model); ?>

		<div class="row">
		<?php echo $form->labelEx($model,'FIRST_NAME'); ?>
		<?php echo $form->textField($model, 'FIRST_NAME', array('maxlength' => 50)); ?>
		<?php echo $form->error($model,'FIRST_NAME'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'LAST_NAME'); ?>
		<?php echo $form->textField($model, 'LAST_NAME', array('maxlength' => 50)); ?>
		<?php echo $form->error($model,'LAST_NAME'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'EMAIL_ID'); ?>
		<?php echo $form->textField($model, 'EMAIL_ID', array('maxlength' => 128)); ?>
		<?php echo $form->error($model,'EMAIL_ID'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'MOBILE_NUMBER'); ?>
		<?php echo $form->textField($model, 'MOBILE_NUMBER', array('maxlength' => 10)); ?>
		<?php echo $form->error($model,'MOBILE_NUMBER'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'COMMENTS'); ?>
		<?php echo $form->textField($model, 'COMMENTS', array('maxlength' => 500)); ?>
		<?php echo $form->error($model,'COMMENTS'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'CAPTCHA'); ?>
		<?php echo $form->textField($model, 'CAPTCHA', array('maxlength' => 10)); ?>
		<?php echo $form->error($model,'CAPTCHA'); ?>
		</div><!-- row -->


<?php
echo GxHtml::submitButton(Yii::t('app', 'Save'));
$this->endWidget();
?>
</div><!-- form -->