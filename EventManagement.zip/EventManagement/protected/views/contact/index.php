<?php

$this->breadcrumbs = array(
	CONTACT::label(2),
	Yii::t('app', 'Index'),
);

$this->menu = array(
	array('label'=>Yii::t('app', 'Create') . ' ' . CONTACT::label(), 'url' => array('create')),
	array('label'=>Yii::t('app', 'Manage') . ' ' . CONTACT::label(2), 'url' => array('admin')),
);
?>

<h1><?php echo GxHtml::encode(CONTACT::label(2)); ?></h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); 