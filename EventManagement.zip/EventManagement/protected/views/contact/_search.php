<div class="wide form">

<?php $form = $this->beginWidget('GxActiveForm', array(
	'action' => Yii::app()->createUrl($this->route),
	'method' => 'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model, 'id'); ?>
		<?php echo $form->textField($model, 'id'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'FIRST_NAME'); ?>
		<?php echo $form->textField($model, 'FIRST_NAME', array('maxlength' => 50)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'LAST_NAME'); ?>
		<?php echo $form->textField($model, 'LAST_NAME', array('maxlength' => 50)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'EMAIL_ID'); ?>
		<?php echo $form->textField($model, 'EMAIL_ID', array('maxlength' => 128)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'MOBILE_NUMBER'); ?>
		<?php echo $form->textField($model, 'MOBILE_NUMBER', array('maxlength' => 10)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'COMMENTS'); ?>
		<?php echo $form->textField($model, 'COMMENTS', array('maxlength' => 500)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'CAPTCHA'); ?>
		<?php echo $form->textField($model, 'CAPTCHA', array('maxlength' => 10)); ?>
	</div>

	<div class="row buttons">
		<?php echo GxHtml::submitButton(Yii::t('app', 'Search')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->
