<?php

$this->breadcrumbs = array(
	'Manage Contact' => array('admin'),
	$model->ID,
);


?>

<h1>View Contact <?php echo $model->ID; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data' => $model,
	'attributes' => array(
'ID',
'FIRST_NAME',
'LAST_NAME',
'EMAIL_ID',
'MOBILE_NUMBER',
'COMMENTS',
'CAPTCHA',
	),
)); ?>

