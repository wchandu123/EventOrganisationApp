<div class="view">

	<?php echo GxHtml::encode($data->getAttributeLabel('id')); ?>:
	<?php echo GxHtml::link(GxHtml::encode($data->id), array('view', 'id' => $data->id)); ?>
	<br />

	<?php echo GxHtml::encode($data->getAttributeLabel('FIRST_NAME')); ?>:
	<?php echo GxHtml::encode($data->FIRST_NAME); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('LAST_NAME')); ?>:
	<?php echo GxHtml::encode($data->LAST_NAME); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('EMAIL_ID')); ?>:
	<?php echo GxHtml::encode($data->EMAIL_ID); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('MOBILE_NUMBER')); ?>:
	<?php echo GxHtml::encode($data->MOBILE_NUMBER); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('COMMENTS')); ?>:
	<?php echo GxHtml::encode($data->COMMENTS); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('CAPTCHA')); ?>:
	<?php echo GxHtml::encode($data->CAPTCHA); ?>
	<br />

</div>