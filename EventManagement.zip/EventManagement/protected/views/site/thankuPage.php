<div class="pt30 mb15">
    <div class="">
        <div class="wrap640">
            <h3 class="content_title">You have registered successfully!</h3>
        </div>
    </div>
    <div class="white_wrap pb150">
        <div class="wrap640 open_sans">
            <h3 class="thanks_title mt30">Thank you for registering for Events.</h3>

            <div class="thanks_msg_wrap">
                <div class="blue_msg"><a href="<?php echo Yii::app()->createUrl('site');?>">CLICK</a> here to login.</div>
            </div>
        </div>
    </div>
</div>