<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'About',
);
?>
<h1>About</h1>

<p>We are an experienced team of Event Management Specialists who know how to plan, promote and run an event that will achieve your goal. From event production to social impact, fundraising technology services to customer service, we’ve got you covered..</p>
