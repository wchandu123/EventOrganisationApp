<?php
/* @var $this SiteController */
/* @var $model ContactForm */
/* @var $form CActiveForm */

$this->pageTitle=Yii::app()->name . ' - Contact Us';
$this->breadcrumbs=array(
	'Contact',
);
?>

<h1>Contact Us</h1>

<?php if(Yii::app()->user->hasFlash('contact')): ?>

<div class="flash-success">
	<?php echo Yii::app()->user->getFlash('contact'); ?>
</div>

<?php else: ?>

<p>
If you have business inquiries or other questions, please fill out the following form to contact us. Thank you.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'contact-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	
	<div class="row">
		<?php echo $form->labelEx($model,'FIRST_NAME'); ?>
		<?php echo $form->textField($model,'FIRST_NAME'); ?>
		<?php echo $form->error($model,'FIRST_NAME'); ?>
	</div>

	
	<div class="row">
		<?php echo $form->labelEx($model,'LAST_NAME'); ?>
		<?php echo $form->textField($model,'LAST_NAME'); ?>
		<?php echo $form->error($model,'LAST_NAME'); ?>
	</div>
	<div class="row">
		<?php echo $form->labelEx($model,'EMAIL_ID'); ?>
		<?php echo $form->textField($model,'EMAIL_ID'); ?>
		<?php echo $form->error($model,'EMAIL_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'MOBILE_NUMBER'); ?>
		<?php echo $form->textField($model,'MOBILE_NUMBER', array('maxlength' => 10)); ?>
		<?php echo $form->error($model,'MOBILE_NUMBER'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'COMMENTS'); ?>
		<?php echo $form->textArea($model,'COMMENTS',array('rows'=>6, 'cols'=>50, 'maxlength' => 500)); ?>
		<?php echo $form->error($model,'COMMENTS'); ?>
	</div>

	<?php if(CCaptcha::checkRequirements()): ?>
	<div class="row">
		<?php echo $form->labelEx($model,'CAPTCHA'); ?>
		<div>
		<?php $this->widget('CCaptcha'); ?>
		<?php echo $form->textField($model,'CAPTCHA'); ?>
		</div>
		<div class="hint">Please enter the letters as they are shown in the image above.
		<br/>Letters are not case-sensitive.</div>
		<?php echo $form->error($model,'CAPTCHA'); ?>
	</div>
	<?php endif; ?>

	<div class="row buttons">
		<?php echo CHtml::submitButton('Submit'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->

<?php endif; ?>