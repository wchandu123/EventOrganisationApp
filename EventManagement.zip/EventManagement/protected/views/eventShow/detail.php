<?php

$this->breadcrumbs=array(
	'Events'=>array('index'),
	$model->title,
);

?>
    
<h1>View <?php echo $model->title; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'title',
                array(        
                    'name'=>'image',
                    'value'=>CHtml::image(Yii::app()->getBaseUrl(true) . '/images/events/'.$model->image,'alt',array("width"=>"200px" ,"height"=>"50px")),
                    'type'  => 'raw',
                ),
                array(
                    'name'  => 'Available Seats',
                    'value'=> $model->getAvailableSeats(),
                ),
		'start_date_time',
		'end_date_time',
		'location',
                array(
                    'name'  => 'Event Timings',
                    'value'=> $model->gettimings(),
                ),
		'typeID',
                array(
                    'name'  => 'link',
                    'value'=>CHtml::link($model->link,$model->link,array('target'=>'_blank')),
                    'type'  => 'raw',
                ),
		'total_seats',
		'booked_seats',
                array(
                    'name'  => 'RSVP',
                    'value'=>CHtml::link('RSVP','#',array('onclick'=>'getLoginUser("'.$model->eventID.'")')),
                    'type'  => 'raw',
                    'visible' => $model->RSVPVisibility(),
                ),
                array(
                   // 'value'=>CHtml::image(Yii::app()->getBaseUrl(true) . '/images/fbshare.png','alt',array("width"=>"100px" ,"height"=>"30px","onclick"=>"shareOnFb(".$model->link.")")),
                    'value'=>CHtml::link('Share on FB','#',array('onclick'=>'shareOnFB("'.$model->link.'")')),
                    'type'  => 'raw',
                ),
	),
)); ?>

<script>(function(d, s, id) {

  var js, fjs = d.getElementsByTagName(s)[0];

  if (d.getElementById(id)) return;

  js = d.createElement(s); js.id = id;

  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5";

  fjs.parentNode.insertBefore(js, fjs);

}(document, 'script', 'facebook-jssdk'));


function shareOnFB(link) {
FB.ui({

        method: "feed",

        link: link,

        picture: "",

        name: "",

        caption: 'events.com ',

        description: "Enjoy with us"

      }, function(t){

        var str = JSON.stringify(t);

        var obj = JSON.parse(str);

        if(obj.post_id != '')

        {

           //after successful sharing, you can show your download content here

        }

      });

}

</script>


<script type="text/javascript">
    function getLoginUser(event_id){
        var user = "<?php  echo ApplicationSessions::run()->read('email');?>"

        if(user != ''){
           
			$.ajax({
			type: "POST",
			url :  "<?php echo Yii::app()->createUrl('eventShow/booking') ?>",
			data : 'event_id=' + event_id,
			success : function(response){
				if(response == 'success'){
					alert('Thank you for Booking Event. Your seat has been booked.');
				} else if(response == 'exist') {
					alert('You have already booked this event.');
				} else if(response == 'Seats are full') {
					alert('All seats are booked.');
				} else {
					alert('Event booking fail.Please try after some time.');
				}
				$('#event_list').val('');
			}
		});
        }
        else{
            window.location.href = "<?php echo Yii::app()->createUrl('site/login'); ?>";
        }
    }

    

</script>
