<style type="text/css">
.input-group.input-group-unstyled input.form-control {
    -webkit-border-radius: 4px;
       -moz-border-radius: 4px;
            border-radius: 4px;
            float:right;
}
.input-group-unstyled .input-group-addon {
    border-radius: 4px;
    border: 0px;
    background-color: transparent;
}
.carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width:500px;
      height:360px;
      margin: auto;
  }
</style>

   <!-- <div class="row">
        <!-- input box -->
       <!-- <div class="form-group col-lg-4">
            <div class="form-group has-feedback">
                <label class="control-label" for="inputValidation"> </label>
                <input type="text" class="form-control" id="inputValidation" placeholder="Search"/>
                <span class="glyphicon glyphicon-search form-control-feedback"></span>
            </div>
        </div>
    </div> -->

    <h4>
    <?php
      if(!empty($featuredEvents))
        echo "Featured Events";
      else
        echo "Upcoming Events";
    ?>
  </h4>
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php
            if(!empty($featuredEvents)){?>
                <?php foreach($featuredEvents as $k=>$v)
                {
                    if($k == 0)
                        $active = 'active';
                    else
                        $active = '';
                    ?>
                    <div class="item <?php echo $active; ?>">
                        <img src="<?php echo Yii::app()->request->baseUrl.'/images/events/'.$v->image ?>" alt="Chania" width="460" height="345">
                        <div class="carousel-caption">
                            <h4><?php echo $v->title;?></h4>
                            <p><?php echo $v->description; ?></p>
                            <p><a href="<?php echo Yii::app()->createUrl('eventShow/detail',array('id'=>$v->eventID)); ?>" >Read More</a></p>
                        </div>
                    </div>
                    <?php
                }
            }
            else
            {
                ?>
                <?php
                foreach($events as $k=>$v)
                {
                    if($k == 0)
                        $active = 'active';
                    else
                        $active = '';
                    ?>
                    <div class="item <?php echo $active; ?>">
                        <img src="<?php echo Yii::app()->request->baseUrl.'/images/events/'.$v->image ?>" alt="Chania" width="460" height="345">
                        <div class="carousel-caption">
                            <h4><?php echo $v->title;?></h4>
                            <p><?php echo $v->description; ?></p>
                            <p><a href="<?php echo Yii::app()->createUrl('eventShow/detail',array('id'=>$v->eventID)); ?>" >Read More</a></p>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


<script type="text/javascript">
    $( "#inputValidation" ).on( 'click', tapHandler );
    function tapHandler( event ) {
            alert('ddddd');
             $('.search_field').toggle();
             $('.search').focus();
    }

    $(function() {
     
        $( ".inputValidation" ).on( 'click', tapHandler );
            
        function tapHandler( event ) {
            alert('ooooo');
          $('.search_field').toggle();
           $('.search').focus();
        }
        
    });
</script> 