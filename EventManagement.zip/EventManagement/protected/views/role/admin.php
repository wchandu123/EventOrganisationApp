<?php
/* @var $this RoleController */
/* @var $model Role */

$this->breadcrumbs=array(
	'Roles'=>array('admin'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Create Role', 'url'=>array('create')),
);

?>

<h1>Manage Roles</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'role-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		array('header'=>'SN.',
                    'value'=>'++$row',
                ),
		'name',
		'description',
		'created',
		'modified',
		array(
			'class'=>'CButtonColumn',
		),
	),
)); ?>
