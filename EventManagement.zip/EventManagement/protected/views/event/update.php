<?php
/* @var $this EventController */
/* @var $model EVENT */

$this->breadcrumbs=array(
	'Events'=>array('admin'),
	$model->title=>array('','id'=>$model->eventID),
);

$this->menu=array(
	array('label'=>'Manage EVENT', 'url'=>array('admin')),
);
?>

<h1>Update Event</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>