<?php
/* @var $this EventController */
/* @var $model EVENT */

$this->breadcrumbs=array(
	'Events'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Create Event', 'url'=>array('create')),
);
?>

<h1>Manage Events</h1>

<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'event-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		array('header'=>'SN.',
                    'value'=>'++$row',
                ),
		'title',
		'image',
		'start_date_time',
		'end_date_time',
		'location',
		/*
		'TYPE_ID',
		'LINK',
		'TOTAL_SEATS',
		'BOOKED_SEATS',
		'CREATED_BY',
		'CREATED_AT',
		'MODIFIED_BY',
		'MODIFIED_AT',
		*/
		array(
			'class'=>'CButtonColumn',
			'template'=>'{update}{delete}'
		),
	),
)); ?>
