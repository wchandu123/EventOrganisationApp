<?php
/* @var $this EventController */
/* @var $model EVENT */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'event-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
        'htmlOptions' => array(
            'enctype' => 'multipart/form-data',
            'class' => 'well',
        ),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'title'); ?>
		<?php echo $form->textField($model,'title',array('maxlength'=>150)); ?>
		<?php echo $form->error($model,'title'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'image'); ?>
		<?php echo $form->fileField($model,'image'); ?>
		<?php echo $form->error($model,'image'); ?>
	</div>
        
        
        <?php if($model->isNewRecord!='1'){ ?>
        <div class="row">
             <?php echo CHtml::image(Yii::app()->request->baseUrl.'/images/events/'.$model->image,"image",array("width"=>200)); ?>  <!-- Image shown here if page is update page-->
        </div>
        <?php } ?>
        
        

	<div class="row">
            <?php echo $form->labelEx($model,'start_date_time'); ?>
            <?php Yii::import('application.extensions.CJuiDateTimePicker.CJuiDateTimePicker');
                $this->widget('CJuiDateTimePicker',array(
                    'model'=>$model, //Model object
                    'attribute'=>'start_date_time', //attribute name
                    'mode'=>'datetime', //use "time","date" or "datetime" (default)
                    'language'=>'',
                    'options'=>array(
                        'regional'=>'',
                        'dateFormat' => 'dd-M-yy',
                        'timeFormat' => 'hh:mm tt',// default


                    ) // jquery plugin options
                ));
            ?>		
            <?php echo $form->error($model,'start_date_time'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'end_date_time'); ?>
		<?php Yii::import('application.extensions.CJuiDateTimePicker.CJuiDateTimePicker');
                    $this->widget('CJuiDateTimePicker',array(
                        'model'=>$model, //Model object
                        'attribute'=>'end_date_time', //attribute name
                        'mode'=>'datetime', //use "time","date" or "datetime" (default)
                        'language'=>'',
                        'options'=>array(
                                'regional'=>'',
                                'dateFormat' => 'dd-M-yy',
                                'timeFormat' => 'hh:mm tt',
                            ) // jquery plugin options
                    ));
                ?>
		<?php echo $form->error($model,'end_date_time'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'location'); ?>
		<?php echo $form->textField($model,'location',array('maxlength'=>200)); ?>
		<?php echo $form->error($model,'location'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'type'); ?>
		<?php echo $form->textField($model,'type',array('maxlength'=>20)); ?>
		<?php echo $form->error($model,'type'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'link'); ?>
		<?php echo $form->textField($model,'link',array('maxlength'=>200)); ?>
		<?php echo $form->error($model,'link'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'total_seats'); ?>
		<?php echo $form->textField($model,'total_seats'); ?>
		<?php echo $form->error($model,'total_seats'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'featured_event'); ?>
		<?php echo $form->radioButtonList($model,'featured_event',array('1'=>'Yes','0'=>'No'),array(
    			'labelOptions'=>array('style'=>'display:inline'),'separator'=>'')); ?>
		<?php echo $form->error($model,'featured_event'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'description'); ?>
		<?php echo $form->textArea($model,'description',array('maxlength'=>500)); ?>
		<?php echo $form->error($model,'description'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->