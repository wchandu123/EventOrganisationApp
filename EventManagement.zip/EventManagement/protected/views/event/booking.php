
<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'booking-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>



	<div class="row">
		<?php $event_list =  CHtml::listData(Event::model()->findAll(), 'eventID', 'title'); ?>       
		<?php echo CHtml::label(Yii::t('demo', 'Select Event: <span class="required">*</span>'), 'event'); ?>
		<?php echo CHtml::dropDownList('event_list','', $event_list ,array('empty'=>'Select Option', 'class' => 'form-control', 'onChange' => 'hideAlertDiv()'));?>
			<div id="event_alert_div" style=" color : red; display:none"></div>
	</div>


	


	<div class="row buttons">
		<?php echo CHtml::button('Submit', array('onclick' => 'bookEvent()')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->


<script>
	function bookEvent(){
		var event_id = $('#event_list').val();
		if(event_id ==  ''){
			$('#event_alert_div').html('Please Select Event.');
			$('#event_alert_div').show();
			return false;
		}
		$.ajax({
			type: "POST",
			url :  "<?php echo Yii::app()->createUrl('Event/booking') ?>",
			data : 'event_id=' + event_id,
			success : function(response){
				if(response == 'success'){
					alert('Thank you for Booking Event. Your seat has been booked.');
				} else if(response == 'exist') {
					alert('You have already booked this event.');
				} else if(response == 'Seats are full') {
					alert('All seats are booked.');
				} else {
					alert('Event booking fail.Please try after some time.');
				}
				$('#event_list').val('');
			}
		});
		
	}
	
	function hideAlertDiv(){
		$('#event_alert_div').hide();
	}
</script>