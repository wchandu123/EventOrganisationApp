<?php
/* @var $this EventController */
/* @var $model EVENT */

$this->breadcrumbs=array(
	'Events'=>array('index'),
	$model->title,
);

$this->menu=array(
	array('label'=>'List EVENT', 'url'=>array('index')),
	array('label'=>'Create EVENT', 'url'=>array('create')),
	array('label'=>'Update EVENT', 'url'=>array('update', 'id'=>$model->eventID)),
	array('label'=>'Delete EVENT', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->eventID),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage EVENT', 'url'=>array('admin')),
);
?>

<h1>View Event <?php echo $model->title; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'title',
		'image',
		'start_date_time',
		'end_date_time',
		'location',
		'type',
		'link',
		'total_seats',
		'booked_seats',
		array('label' => 'Available Seats',
			  'value' => $model->getAvailableSeats($model->eventID)),
		
	),
)); ?>
