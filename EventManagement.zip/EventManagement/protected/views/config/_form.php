<?php
/* @var $this ConfigController */
/* @var $model Config */
/* @var $form CActiveForm */
?>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'config-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'htmlOptions'=>array('class'=>'well','enctype'=>'multipart/form-data'),
	'enableAjaxValidation'=>false,
)); ?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php //echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'site_name'); ?>
		<?php echo $form->textField($model,'site_name',array('maxlength'=>300)); ?>
		<?php echo $form->error($model,'site_name'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'site_email'); ?>
		<?php echo $form->textField($model,'site_email',array('maxlength'=>400)); ?>
		<?php echo $form->error($model,'site_email'); ?>
	</div>
	
	<div class="row">
		<?php if (!empty($model->logo)){?>
				<img src="<?php echo Yii::app()->baseUrl.'/images/logo/'.$model->logo; ?>" alt="logo" style="width: 400px;"/>
			<?php }?>
	</div>
	<div class="row">
		<?php echo $form->labelEx($model,'logo'); ?>
		<?php echo $form->fileField($model,'logo',array('maxlength'=>500)); ?>
		<?php echo $form->error($model,'logo'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->