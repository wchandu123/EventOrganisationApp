<?php
/* @var $this ConfigController */
/* @var $model Config */

$this->breadcrumbs=array(
	'Configs'=>array('index'),
	'Create',
);


?>

<h1>Set Website Name and Logo</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>