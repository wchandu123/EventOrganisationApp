<?php

$this->breadcrumbs = array(
	'Booking Details' => array('admin'),
	$model->ID,
);



?>

<h1>View Booking <?php echo $model->ID; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data' => $model,
	'attributes' => array(
'ID',
array('name'=>'EVENT_ID',
      'value' => BOOKINGMODEL::getEventTitle($model->EVENT_ID)),

array('name'=>'USER_ID',
      'value' => BOOKINGMODEL::getUserName($model->USER_ID)),
'CREATED',
	),
)); ?>

