<div class="wide form">

<?php $form = $this->beginWidget('GxActiveForm', array(
	'action' => Yii::app()->createUrl($this->route),
	'method' => 'get',
)); ?>

	<div class="row">
		<?php echo $form->label($model, 'ID'); ?>
		<?php echo $form->textField($model, 'ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'EVENT_ID'); ?>
		<?php echo $form->textField($model, 'EVENT_ID'); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'USER_ID'); ?>
		<?php echo $form->textField($model, 'USER_ID', array('maxlength' => 20)); ?>
	</div>

	<div class="row">
		<?php echo $form->label($model, 'CREATED'); ?>
		<?php echo $form->textField($model, 'CREATED'); ?>
	</div>

	<div class="row buttons">
		<?php echo GxHtml::submitButton(Yii::t('app', 'Search')); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->
