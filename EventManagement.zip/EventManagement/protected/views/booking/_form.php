<div class="form">


<?php $form = $this->beginWidget('GxActiveForm', array(
	'id' => 'bookingmodel-form',
	'enableAjaxValidation' => false,
));
?>

	<p class="note">
		<?php echo Yii::t('app', 'Fields with'); ?> <span class="required">*</span> <?php echo Yii::t('app', 'are required'); ?>.
	</p>

	<?php echo $form->errorSummary($model); ?>

		<div class="row">
		<?php echo $form->labelEx($model,'EVENT_ID'); ?>
		<?php echo $form->textField($model, 'EVENT_ID'); ?>
		<?php echo $form->error($model,'EVENT_ID'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'USER_ID'); ?>
		<?php echo $form->textField($model, 'USER_ID', array('maxlength' => 20)); ?>
		<?php echo $form->error($model,'USER_ID'); ?>
		</div><!-- row -->
		<div class="row">
		<?php echo $form->labelEx($model,'CREATED'); ?>
		<?php echo $form->textField($model, 'CREATED'); ?>
		<?php echo $form->error($model,'CREATED'); ?>
		</div><!-- row -->


<?php
echo GxHtml::submitButton(Yii::t('app', 'Save'));
$this->endWidget();
?>
</div><!-- form -->