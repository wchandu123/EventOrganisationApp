<?php

$this->breadcrumbs = array(
	'Booking Details' => array('admin'),
	'Manage',
);


Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$.fn.yiiGridView.update('bookingmodel-grid', {
		data: $(this).serialize()
	});
	return false;
});
");
?>


<h1> Manage Booking</h1>


<?php $this->widget('zii.widgets.grid.CGridView', array(
	'id' => 'bookingmodel-grid',
	'dataProvider' => $model->search(),
	'filter' => $model,
	'columns' => array(
		
		array('name' =>'EVENT_ID',
			  'type' => 'raw',
		      'value' =>'BOOKINGMODEL::getEventTitle($data->EVENT_ID)'),
		array('name' =>'USER_ID',
			  'type' => 'raw',
		      'value' =>'BOOKINGMODEL::getUserName($data->USER_ID)'),
		
		'CREATED',
		array(
			'class' => 'CButtonColumn',
                        'template'=>'{view}{delete}',
		),
	),
)); ?>
