<div class="view">

	<?php echo GxHtml::encode($data->getAttributeLabel('ID')); ?>:
	<?php echo GxHtml::link(GxHtml::encode($data->ID), array('view', 'id' => $data->ID)); ?>
	<br />

	<?php echo GxHtml::encode($data->getAttributeLabel('EVENT_ID')); ?>:
	<?php echo GxHtml::encode($data->EVENT_ID); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('USER_ID')); ?>:
	<?php echo GxHtml::encode($data->USER_ID); ?>
	<br />
	<?php echo GxHtml::encode($data->getAttributeLabel('CREATED')); ?>:
	<?php echo GxHtml::encode($data->CREATED); ?>
	<br />

</div>