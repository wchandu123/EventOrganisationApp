<?php
/**
 * Controller is the customized base controller class.
 * All controller classes for this application should extend from this base class.
 */
class Controller extends CController
{
	/**
	 * @var string the default layout for the controller view. Defaults to '//layouts/column1',
	 * meaning using a single column layout. See 'protected/views/layouts/column1.php'.
	 */
	public $layout='//layouts/column1';
	/**
	 * @var array context menu items. This property will be assigned to {@link CMenu::items}.
	 */
	public $menu=array();
	/**
	 * @var array the breadcrumbs of the current page. The value of this property will
	 * be assigned to {@link CBreadcrumbs::links}. Please refer to {@link CBreadcrumbs::links}
	 * for more details on how to specify this property.
	 */
	public $breadcrumbs=array();

	public static function encrypting($val="") 
    {
    	$abc= hash('whirlpool',base64_decode($val));
       return $abc;
    }

    public  static function getMenu()
    {
	    $menuName = array();
    	$menu= Menus::model()->getList("ALL");

		foreach ($menu as $key1 => $value1)
        {
            		if($value1->parentID==0)
            		{
            			$child = self :: getChild($menu, $value1->menuID);
                        if (!empty($child)){
                            foreach ($child as $key => $value) {
                                if($value['visible'] == 1){
                                    $visible = 1;
                                    break;
                                }else{
                                    $visible = 0;
                                }
                            }
                        }
                        else
                        {
                            $visible = self::getMenuVisiblity($value1->system_url);            			     
                        }
                        $menuName[] = array('url'=>Yii::app()->createUrl($value1->system_url) , 'label'=>$value1->menu_name, 'visible'=>$visible,'items' => $child );
            	        
            		}			
		}      
		
		return $menuName;
    }

    public static function getChild($menu, $id)
    {
    	$items = array();
	
		foreach ($menu as $key => $value){
			if($value->parentID == $id)
			{
				
				$subchild = array();
				
						foreach ($menu as $key1 => $value1)
						{
								
							if($value1->parentID == $value->menuID)
							{								
								$subchild[] = array('url'=>Yii::app()->createUrl($value1->system_url), 'label'=>$value1->menu_name, 'visible'=>self::getMenuVisiblity($value1->system_url));
								
							}
							
						}
				$items[] = array('url'=>Yii::app()->createUrl($value->system_url) , 'label'=>$value->menu_name, 'visible'=>self::getMenuVisiblity($value->system_url),'items' => $subchild);
				
			}
		}
		//print_r($items);exit;
		return $items;
	}


    public static function getMenuVisiblity($sysurl, $id = null)
    {
    	if(Yii::app()->user->isGuest) {
    		return 0;
    	}
    	else 
    	{
            $role_menu = ApplicationSessions::run()->read('permissions');
            if(!empty($role_menu))
            {
                $role_menu = explode(",",str_replace('.','/',strtolower($role_menu[0])));
                
                if(in_array(strtolower($sysurl), $role_menu))
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            }else
                return 0;
    	}
    }

    function getRandomString($length = 8) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $string = '';

        for ($i = 0; $i < $length; $i++) {
            $string .= $characters[mt_rand(0, strlen($characters) - 1)];
        }

        return $string;
    }

    public static function sendMail($subject,$body,$to_email,$to_name,$attachment = null)
    {
    $content_type="text/html";
    $charset="UTF-8";
    $from_email = "email@gmail.com";//$to_email;
    $from_name = "Event Management Sysytem";
      $body = nl2br($body);
      $headers =  "From: Event Management Sysytem <$from_email>" . "\r\n" .
              "Reply-To: Event Management Sysytem <$from_email>" . "\r\n" .
              'X-Mailer: PHP/' . phpversion()."\r\n";
    $headers  .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    //mail($to_email, $subject, $body, $headers); 
    try
    {
        Yii::import('application.extensions.phpmailer.JPhpMailer');
        $mail = new JPhpMailer;
      $mail->IsSMTP();
      $mail->Mailer = "smtp";
      $mail->SMTPSecure = "ssl"; 
      $mail->Host='smtp.gmail.com';   
      $mail->Port='465';   
      $mail->SMTPAuth = true;
      $mail->Username = "testmail@gmail.com";
      $mail->Password = "testmail";
      $mail->SetFrom($from_email,$from_name);
      //if($to_bcc)
        //$mail->AddBCC($to_bcc);
      if($attachment)
      {
        if(is_array($attachment))
        {
          foreach ($attachment as $key => $value) 
          {
            $mail->AddAttachment($value);
          } 
        }
        else
          $mail->AddAttachment($attachment);
      }
      $mail->Subject =$subject;
      $mail->MsgHTML($body);
      $mail->AddAddress($to_email,$to_name);
      $mail->Send();
      return true;
      }
    catch (phpmailerException $e)
    {
      //echo $e->errorMessage(); //Pretty error messages from PHPMailer
      return false;
    }
    catch (Exception $e) 
    {
      //echo $e->getMessage(); //Boring error messages from anything else!
      return false;
    }
  }
}