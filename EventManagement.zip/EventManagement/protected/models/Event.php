<?php

/**
 * This is the model class for table "tbl_event".
 *
 * The followings are the available columns in table 'tbl_event':
 * @property integer $eventID
 * @property integer $type
 * @property string $title
 * @property string $image
 * @property string $start_date_time
 * @property string $end_date_time
 * @property string $location
 * @property string $link
 * @property integer $total_seats
 * @property integer $booked_seats
 * @property integer $featured_event
 * @property string $description
 * @property string $created
 * @property string $modified
 */
class Event extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_event';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('title, image, start_date_time, end_date_time, location, total_seats,', 'required'),
			array(' total_seats, booked_seats, featured_event', 'numerical', 'integerOnly'=>true),
			array('title, image, location', 'length', 'max'=>200),
			array('link', 'length', 'max'=>400),
			array('description', 'length', 'max'=>500),
			array('modified', 'default', 'value' => new CDbExpression('NOW()'),'setOnEmpty' => false, 'on' => 'update'),
         	array('modified,created', 'default', 'value' => new CDbExpression('NOW()'), 'setOnEmpty' => false, 'on' => 'insert'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('eventID, type, title, image, start_date_time, end_date_time, location, link, total_seats, booked_seats, featured_event, description, created, modified', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'eventID' => 'Event',
			'type' => 'Type',
			'title' => 'Title',
			'image' => 'Image',
			'start_date_time' => 'Start Date Time',
			'end_date_time' => 'End Date Time',
			'location' => 'Location',
			'link' => 'Link',
			'total_seats' => 'Total Seats',
			'booked_seats' => 'Booked Seats',
			'featured_event' => 'Featured Event',
			'description' => 'Description',
			'created' => 'Created',
			'modified' => 'Modified',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('eventID',$this->eventID);
		$criteria->compare('type',$this->type);
		$criteria->compare('title',$this->title,true);
		$criteria->compare('image',$this->image,true);
		$criteria->compare('start_date_time',$this->start_date_time,true);
		$criteria->compare('end_date_time',$this->end_date_time,true);
		$criteria->compare('location',$this->location,true);
		$criteria->compare('link',$this->link,true);
		$criteria->compare('total_seats',$this->total_seats);
		$criteria->compare('booked_seats',$this->booked_seats);
		$criteria->compare('featured_event',$this->featured_event);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('created',$this->created,true);
		$criteria->compare('modified',$this->modified,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			'sort'=>array(
        		'defaultOrder'=>'eventID DESC',
        		 ),
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Event the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public static function getEvents(){
            $criteria=new CDbCriteria;
            $criteria->select='image,featured_event,description,link,start_date_time,end_date_time,title,eventID';
            $criteria->order= 'start_date_time DESC';
            $criteria->limit= '4';

            //Apply To Model
            $model = Event::model()->findAll($criteria);
            return $model;
        }
        public static function getFeaturedEvents(){
            $criteria=new CDbCriteria;
            $criteria->select='image,featured_event,description,link,start_date_time,end_date_time,title,eventID';
            $criteria->addCondition('featured_event = :value');
            $criteria->params = array(
                ':value' => '1',
            );
            $criteria->order= 'eventID DESC';
            //Apply To Model
            $model = Event::model()->findAll($criteria);
            return $model;
        }
        
        public function getAvailableSeats(){
            return ($this->total_seats - $this->booked_seats);
        }
        
        public function gettimings(){
            return substr($this->start_date_time,10,5). "-" .substr($this->end_date_time,10,5);
        }
        
        public function RSVPVisibility(){
            if($this->total_seats - $this->booked_seats >= 1)
                return true;
            else 
                return false;
        }
		
}
