<?php

/**
 * This is the model class for table "tbl_booking".
 *
 * The followings are the available columns in table 'tbl_booking':
 * @property integer $ID
 * @property integer $EVENT_ID
 * @property integer $USER_ID
 * @property string $CREATED
 */
class BOOKINGMODEL extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_booking';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('EVENT_ID, USER_ID', 'numerical', 'integerOnly'=>true),
			array('CREATED', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('ID, EVENT_ID, USER_ID, CREATED', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'ID' => 'ID',
			'EVENT_ID' => 'Event',
			'USER_ID' => 'User',
			'CREATED' => 'Created',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('ID',$this->ID);
		$criteria->compare('EVENT_ID',$this->EVENT_ID);
		$criteria->compare('USER_ID',$this->USER_ID);
		$criteria->compare('CREATED',$this->CREATED,true);
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return BOOKINGMODEL the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
	public static function getEventTitle($event_id){
		$title = '';
		$data = Event::model()->find(array('condition' => 'eventID = :EVENT_ID', 'params' => array(':EVENT_ID'=>$event_id)));
		if(!empty($data)){
			$title = $data->title;
		}
		return $title;
	}
	
	public static function getUserName($user_id){
		$name = '';
		$data = Users::model()->find(array('condition' => 'id = :user_id', 'params' => array(':user_id'=>$user_id)));
		if(!empty($data)){
			$name = $data->first_name;
		}
		return $name;
		
	}
}
