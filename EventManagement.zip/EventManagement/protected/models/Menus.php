<?php

/**
 * This is the model class for table "tbl_menus".
 *
 * The followings are the available columns in table 'tbl_menus':
 * @property integer $menuID
 * @property integer $main_menuID
 * @property string $menu_name
 * @property string $menu_image
 * @property string $menu_description
 * @property integer $parentID
 * @property integer $sortOrder
 * @property string $system_url
 * @property integer $active
 * @property string $created
 * @property string $modified
 */
class Menus extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'tbl_menus';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('menu_name, system_url, menu_description,active', 'required'),
			array('parentID, sortOrder, active', 'numerical', 'integerOnly'=>true),
			array('menu_name', 'length', 'max'=>300),
			array('system_url', 'length', 'max'=>400),
			array('menu_description', 'safe'),
			array('menu_name', 'length', 'max'=>300),
			array('modified', 'default', 'value' => new CDbExpression('NOW()'),'setOnEmpty' => false, 'on' => 'update'),
         	array('modified,created', 'default', 'value' => new CDbExpression('NOW()'), 'setOnEmpty' => false, 'on' => 'insert'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('menuID, menu_name, menu_description, parentID, sortOrder, system_url, active, created, modified', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'menuID' => 'Menu',
			'menu_name' => 'Menu Name',
			'menu_description' => 'Menu Description',
			'parentID' => 'Parent',
			'sortOrder' => 'Sort Order',
			'system_url' => 'System Url',
			'active' => 'Active',
			'created' => 'Created',
			'modified' => 'Modified',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search($pid = null)
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('menuID',$this->menuID);
		$criteria->compare('menu_name',$this->menu_name,true);
		$criteria->compare('menu_description',$this->menu_description,true);
		$criteria->compare('parentID',$pid);
		$criteria->compare('sortOrder',$this->sortOrder);
		$criteria->compare('system_url',$this->system_url,true);
		$criteria->compare('active',$this->active);
		$criteria->compare('created',$this->created,true);
		$criteria->compare('modified',$this->modified,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			'sort'=>array(
        		'defaultOrder'=>'menuID DESC',
        		 ),
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Menus the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public static function getList($type, $arrParams = array())
    {
        switch ($type)
        {
            case 'PARENT-LIST':
                return Menus::model()->findAll(array('condition'=>'active=1 AND parentID=0'));
                break;
				
				case 'ALL':
                return Menus::model()->findAll();
                break;
                
                case 'FRONTEND':
                return Menus::model()->findAll(array('condition'=> 'active=1'));
                break;
                
                case 'FRONTEND-CHILD':
                return Menus::model()->findAll(array('condition'=>'active=1'));
                break;
                
        }
    }

    public function getModel($type, $arrParams = array())
    {
        switch ($type)
        {
            case 'MENU-ID':
                $a= Menus::model()->findByPk($arrParams['menuID']);
				echo '<pre>'; print_r($a->getAttributes('menu_name'));
                break;
				
			case 'MENU-ID-NAME':
                $a= Menus::model()->findByPk($arrParams['menuID']);
				if(!empty($a))
				return $a->getAttribute('menu_name');
				else
				return '';
                break;	

        }
    }
    
}
