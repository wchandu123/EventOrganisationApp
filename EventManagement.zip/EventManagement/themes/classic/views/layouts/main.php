<?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="language" content="en">

	<!-- blueprint CSS framework -->
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/screen.css" media="screen, projection">
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/print.css" media="print">
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/ie.css" media="screen, projection">
	<![endif]-->

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css">

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/style.css">

	<!-- for carousel -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>


	<title><?php echo CHtml::encode($this->pageTitle); ?></title>
	<style>
		#mainmenu ul { list-style: none; margin: 0; padding: 0; position: relative; height: 26px; }
		#mainmenu ul li { display: block; float: left; overflow: visible; }
		#mainmenu ul li:hover > ul { display: block; }
		#mainmenu ul li a { float: left; display: block; }
		#mainmenu ul li ul { display: none; position: absolute; top: 100%; background: #589FC8; color: #fff; height: auto; width: auto; }
		#mainmenu ul li ul li a { color: #fff; padding: 4px 14px; display: block; width: 120px;}
		#mainmenu ul li ul li.active a, #mainmenu ul li ul li a:hover { color: #589FC8; }
		#mainmenu ul li ul li { clear: left;}
	</style>
</head>

<body>

<div class="container" id="page">

	<div id="header">
		<div id="logo"><?php
			$objconfig = Config::getModel('CONFIG-ID',array('configID'=>1));

			echo CHtml::image(Yii::app()->getBaseUrl(true) . '/images/logo/'.$objconfig->logo,'alt',array("width"=>"100px" ,"height"=>"50px"));
		  ?></div>
	</div><!-- header -->

	<?php   $menuarray = Controller::getMenu();
		
		$generic1 = array(
					'0' => array(
                            'url' => Yii::app()->createUrl("/eventShow"),
                            'label' => "Home",
                            'visible' => 1,
                        ),
                    '1' => array(
                            'url' => Yii::app()->createUrl("/site/login"),
                            'label' => "Login",
                            'visible' => Yii::app()->user->isGuest,
                        ),
                );
		$generic2 = array(
				'0' => array(
                        'url' => Yii::app()->createUrl("/site/logout"),
                        'label' => "Logout(".ApplicationSessions::run()->read('user').")",
                        'visible' => !Yii::app()->user->isGuest,
                    	'itemOptions'=>array('style'=>'float: right;')
                    ),
			);

        if(empty($menuarray)){
        	$menuarray = array_merge($generic1, $generic2);;
        } else
        {
        	$menuarray = array_merge($generic1, $menuarray);
        	$menuarray = array_merge($menuarray, $generic2);
        }

       // echo "<pre>";print_r($menuarray);exit;
                
?>
		
		

	<div id="mainmenu">

		<?php 
		 $this->widget('zii.widgets.CMenu',array(
		 		'activeCssClass'=>'active',
  				'activateParents'=>true,
		 		'items'=>$menuarray,
		 	)); 
		?>

	</div><!-- mainmenu -->
	<?php if(isset($this->breadcrumbs)):?>
		<?php $this->widget('zii.widgets.CBreadcrumbs', array(
			'links'=>$this->breadcrumbs,
		)); ?><!-- breadcrumbs -->
	<?php endif?>


	<?php echo $content; ?>

	<div class="clear"></div>

	<div id="footer">
	<div>
		<a href="<?php echo Yii::app()->createUrl('/site/page', array('view'=>'about')) ?>">About Us </a> &nbsp; &nbsp;
		<a href="<?php echo Yii::app()->createUrl('/site/contact') ?>">Contact Us</a>
		</div>
		Copyright &copy; <?php echo date('Y'); ?> by Chandrakala.<br/>
		All Rights Reserved.
	</div><!-- footer -->

</div><!-- page -->

</body>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</html>
