-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2017 at 07:54 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventorganisationdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `ID` int(11) NOT NULL,
  `EVENT_ID` int(11) DEFAULT NULL,
  `USER_ID` int(11) DEFAULT NULL,
  `CREATED` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`ID`, `EVENT_ID`, `USER_ID`, `CREATED`) VALUES
(6, 4, 1, '2017-01-01 23:45:02'),
(7, 4, 7, '2017-01-02 00:00:26');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_config`
--

CREATE TABLE `tbl_config` (
  `configID` int(11) NOT NULL,
  `site_name` varchar(300) NOT NULL,
  `site_email` varchar(400) NOT NULL,
  `logo` varchar(500) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_config`
--

INSERT INTO `tbl_config` (`configID`, `site_name`, `site_email`, `logo`, `created`, `modified`) VALUES
(1, 'Event Management', 'event.management.gmail.com', 'b7ba0362d6ff51a03ade79ffb0cfee7a.png', '2016-12-29 21:49:04', '2016-12-29 21:52:22');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(50) DEFAULT NULL,
  `LAST_NAME` varchar(50) DEFAULT NULL,
  `EMAIL_ID` varchar(128) DEFAULT NULL,
  `MOBILE_NUMBER` varchar(10) DEFAULT NULL,
  `COMMENTS` varchar(500) DEFAULT NULL,
  `CAPTCHA` varchar(20) DEFAULT NULL,
  `CREATED` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`ID`, `FIRST_NAME`, `LAST_NAME`, `EMAIL_ID`, `MOBILE_NUMBER`, `COMMENTS`, `CAPTCHA`, `CREATED`) VALUES
(2, 'Chandrakala', 'Dhaundiyal', 'preeyaathapliyal@gmail.com', '9999999999', 'Testing', 'jugyqah', '2017-01-01 10:40:35'),
(3, 'Ruchi', 'Thapliyal', 'ruchi@gmail.com', '2222222222', 'Testing', 'eeyedzn', '2017-01-01 10:42:18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_event`
--

CREATE TABLE `tbl_event` (
  `eventID` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `image` varchar(200) NOT NULL,
  `start_date_time` datetime NOT NULL,
  `end_date_time` datetime NOT NULL,
  `location` varchar(200) NOT NULL,
  `link` varchar(400) NOT NULL,
  `total_seats` int(11) NOT NULL,
  `booked_seats` int(11) NOT NULL DEFAULT '0',
  `featured_event` int(1) NOT NULL DEFAULT '0',
  `description` varchar(500) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_event`
--

INSERT INTO `tbl_event` (`eventID`, `type`, `title`, `image`, `start_date_time`, `end_date_time`, `location`, `link`, `total_seats`, `booked_seats`, `featured_event`, `description`, `created`, `modified`) VALUES
(4, '1', 'Star Night', '9584-download (1).jpg', '1970-01-01 05:30:00', '1970-01-01 05:30:00', 'Mumbai', 'http://startNight.co.in', 200, 3, 0, 'Pioneers in the industry, we offer Star Night Event Service, Bollywood Night Event Service, Singer Night Event Service, Indian Music Night Service and Singer Night Event Organizers Service from India.', '2016-12-30 20:51:06', '2017-01-02 00:00:26'),
(5, '', 'Dinner', '8250-download (2).jpg', '2017-01-10 18:00:00', '2016-12-11 03:02:00', 'Khar West', 'http://dinner.out.in', 1, 1, 0, 'Foodies do come and enjoy with us with 50 exotic dishes', '2016-12-31 11:58:46', '2017-01-01 14:22:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_menus`
--

CREATE TABLE `tbl_menus` (
  `menuID` int(11) NOT NULL,
  `menu_name` varchar(300) NOT NULL,
  `menu_description` text,
  `parentID` int(11) NOT NULL,
  `sortOrder` int(11) NOT NULL,
  `system_url` varchar(400) NOT NULL,
  `active` int(11) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_menus`
--

INSERT INTO `tbl_menus` (`menuID`, `menu_name`, `menu_description`, `parentID`, `sortOrder`, `system_url`, `active`, `created`, `modified`) VALUES
(2, 'Admin', 'Admin module for this application', 0, 0, '/event', 1, '2016-12-30 08:16:24', '2016-12-30 08:16:24'),
(3, 'Users', 'User listing for theis application', 2, 0, '/users/index', 1, '2016-12-30 08:17:27', '2016-12-31 08:30:14'),
(4, 'Menu', 'This will have all the menus of this application.', 2, 0, '/menus/admin', 1, '2016-12-31 08:00:51', '2016-12-31 08:00:51'),
(5, 'Role Permission', 'This will have all the role permissions editable by site admin', 2, 0, '/rolePermission/index', 1, '2016-12-31 08:03:39', '2016-12-31 08:30:26'),
(6, 'Role', 'This is the role master. Editable by site admin', 2, 0, '/role/admin', 1, '2016-12-31 08:05:04', '2016-12-31 08:05:04'),
(7, 'Event Lists', 'This menu will contain details of all the events', 2, 0, '/event/admin', 1, '2016-12-31 08:07:31', '2016-12-31 08:07:31'),
(8, 'Booking Details', 'This will show the seats availability for events', 2, 0, '/booking/admin', 1, '2016-12-31 08:08:56', '2016-12-31 08:10:04'),
(9, 'Manage Contact ', 'Manage data submitted by Contact Us form. This is visible to Admin', 2, 0, '/contact/admin', 1, '2017-01-01 11:03:14', '2017-01-01 23:27:45');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(11) NOT NULL,
  `name` varchar(55) DEFAULT NULL,
  `description` text,
  `status` enum('active','inactive') DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `name`, `description`, `status`, `created`, `modified`) VALUES
(1, 'SiteAdmin', '', 'active', '2016-12-29 23:38:46', '2016-12-29 23:38:46'),
(2, 'Auth User', '', 'active', '2016-12-29 23:42:23', '2016-12-29 23:42:23'),
(3, 'Content Auth', '', 'active', '2016-12-29 23:50:30', '2016-12-29 23:50:30'),
(5, 'Users', 'Normal Users', NULL, '2016-12-31 11:04:55', '2016-12-31 11:04:55');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role_permission`
--

CREATE TABLE `tbl_role_permission` (
  `rolePermissionID` int(11) NOT NULL,
  `roleID` int(11) DEFAULT NULL,
  `permissionName` text,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role_permission`
--

INSERT INTO `tbl_role_permission` (`rolePermissionID`, `roleID`, `permissionName`, `created`) VALUES
(1, 1, '.Booking.View,.Booking.Create,.Booking.Update,.Booking.Delete,.Booking.Index,.Booking.Admin,.Config.View,.Config.Index,.Config.Update,.Config.Delete,.Config.Index1,.Contact.View,.Contact.Create,.Contact.Update,.Contact.Delete,.Contact.Index,.Contact.Admin,.Event.View,.Event.Create,.Event.Update,.Event.Delete,.Event.Index,.Event.Admin,.EventShow.Index,.EventShow.Detail,.Menus.View,.Menus.Create,.Menus.Update,.Menus.Delete,.Menus.Index,.Menus.Admin,.Role.View,.Role.Create,.Role.Update,.Role.Delete,.Role.Index,.Role.Admin,.RolePermission.View,.RolePermission.Create,.RolePermission.Update,.RolePermission.Delete,.RolePermission.Index,.RolePermission.Admin,.Site.Login,.Site.Register,.Site.Error,.Site.Contact,.Site.Logout,.Users.AssignRole,.Users.Delete,.Users.Index,.Users.ChangePassword', '2016-12-31 08:01:41'),
(2, 2, '.Booking.View,.Booking.Create,.Booking.Update,.Booking.Delete,.Booking.Index,.Booking.Admin,.Event.View,.Event.Create,.Event.Update,.Event.Delete,.Event.Index,.Event.Admin,.EventShow.Index,.EventShow.Detail,.EventShow.ShareOnFb,.EventShow.Booking', '2017-01-02 00:10:21'),
(3, 3, '.Contact.View,.Contact.Create,.Contact.Update,.Contact.Delete,.Contact.Index,.Contact.Admin', '2017-01-02 00:10:21');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastvisit_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `superuser` int(1) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`id`, `first_name`, `last_name`, `password`, `email`, `create_at`, `lastvisit_at`, `superuser`, `status`, `role`) VALUES
(1, 'Chandrakala', 'Dhaundiyal', '0b6969803ded1df23891203f4cba572fda6d07de0406755484f0a2647c315b8061025dd1c80a1fed9c6afb296a6ebbeaff055cb2eb4d61cc5d7da111c226fb84', 'chandu.dhaundiyal@gmail.com', '2016-12-29 17:33:36', '0000-00-00 00:00:00', 0, 1, '1'),
(3, 'Priya', 'Thapliyal', '0b6969803ded1df23891203f4cba572fda6d07de0406755484f0a2647c315b8061025dd1c80a1fed9c6afb296a6ebbeaff055cb2eb4d61cc5d7da111c226fb84', 'priya.thapliyal@gmail.com', '2016-12-31 05:54:16', '0000-00-00 00:00:00', 0, 1, '2'),
(4, 'Ruchi', 'Thapliyal', '0b6969803ded1df23891203f4cba572fda6d07de0406755484f0a2647c315b8061025dd1c80a1fed9c6afb296a6ebbeaff055cb2eb4d61cc5d7da111c226fb84', 'ruchi.thapliyal@gmail.com', '2017-01-01 05:46:29', '0000-00-00 00:00:00', 0, 1, '2'),
(5, 'Swati', 'Thapliyal', 'b67e2b8aaa2645133b18ebf0b06740358e837a60b92c69edec5bb94e86c9a132d7685a5db72b5d1eea052fe93431a93933d7d2f331f106ed4a4e1ec161837c64', 'swati.thapliyal@gmail.com', '2017-01-01 11:12:12', '0000-00-00 00:00:00', 0, 1, '2'),
(6, 'Auth', 'User', '6713e9b3e2542dd6055bee75da005ec7a723e6ec0c387bbcef26dddfdd6d06d657207de547d0412a8b3522c3959078e16aa94ce7ed51fbc2f8b339a1ff32ba0f', 'authuser@gmail.com', '2017-01-01 11:22:27', '0000-00-00 00:00:00', 0, 1, '2'),
(7, 'Super', 'Admin', 'b5d7ba6f7604431072a8b0dc30c2d9756655eb5fa3c668b46726a72c893018e6f1fc75e2052a0ea74b265580fb23f63b3fa077837cbf92c2407a675dc93c7cce', 'superadmin@gmail.com', '2017-01-01 18:17:40', '0000-00-00 00:00:00', 0, 1, '1'),
(8, 'content', 'user', '85134ca43033052ea88495cd6839017f8a8aa488ed305ce64f817fa18dd354404cc7fcaf294ae5c20c3a311731eb62b4996d6fded9cc453a3a3674a0452a022e', 'contentuser@gmail.com', '2017-01-01 11:12:12', '0000-00-00 00:00:00', 0, 1, '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_config`
--
ALTER TABLE `tbl_config`
  ADD PRIMARY KEY (`configID`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_event`
--
ALTER TABLE `tbl_event`
  ADD PRIMARY KEY (`eventID`);

--
-- Indexes for table `tbl_menus`
--
ALTER TABLE `tbl_menus`
  ADD PRIMARY KEY (`menuID`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  ADD PRIMARY KEY (`rolePermissionID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `status` (`status`),
  ADD KEY `superuser` (`superuser`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_booking`
--
ALTER TABLE `tbl_booking`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_config`
--
ALTER TABLE `tbl_config`
  MODIFY `configID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_event`
--
ALTER TABLE `tbl_event`
  MODIFY `eventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_menus`
--
ALTER TABLE `tbl_menus`
  MODIFY `menuID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `tbl_role_permission`
--
ALTER TABLE `tbl_role_permission`
  MODIFY `rolePermissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
